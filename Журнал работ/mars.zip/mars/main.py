from flask import Flask, render_template, request
from mars.data import db_session
from mars.data.users import User
from mars.data.jobs import Jobs
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/mars_explorer.db")
    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.position = "captain"
    user.speciality = "research engineer"
    user.address = "module_1"
    user.email = "scott_chief@mars.org"
    user2 = User()
    user2.surname = "Winston"
    user2.name = "Smith"
    user2.position = "the captain's mate"
    user2.speciality = "mechanic"
    user2.address = "module_2"
    user2.email = "winston_smith@mars.org"
    job = Jobs()
    job.team_leader = 1
    job.job = "deployment of residential modules 1 and 2"
    job.work_size = 15
    job.collaborators = "2, 3"
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    job2 = Jobs()
    job2.team_leader = 2
    job2.job = "qwerty"
    job2.work_size = 10
    job2.collaborators = "4, 5"
    job2.start_date = datetime.datetime.now()
    job2.is_finished = False
    db_sess = db_session.create_session()
    db_sess.add(user)
    db_sess.add(user2)
    db_sess.add(job)
    db_sess.add(job2)
    db_sess.commit()

    app.run()


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = []
    for job in db_sess.query(Jobs).all():
        cur = {}
        for user in db_sess.query(User).all():
            if user.id == job.team_leader:
                cur["team_leader"] = f"{user.surname} {user.name}"
                break
        cur["id"] = job.id
        cur["job"] = job.job
        cur["work_size"] = job.work_size
        cur["collaborators"] = job.collaborators
        cur["is_finished"] = job.is_finished
        jobs.append(cur)
        print(jobs)
    return render_template("index.html", jobs=jobs)


@app.route("/register", methods=['POST', 'GET'])
def register():
    error = ''
    if request.method == "GET":
        return render_template("register.html", error=error)
    elif request.method == "POST":
        if request.form["password"] != request.form["rep_password"]:
            error = 'Пароли не совпадают'
            return render_template("register.html", error=error)
        user = User()
        user.surname = request.form['surname']
        user.name = request.form['name']
        user.age = request.form['age']
        user.position = request.form['position']
        user.speciality = request.form['speciality']
        user.address = request.form['address']
        user.email = request.form['email']
        user.hashed_password = request.form['password']
        user.modified_date = datetime.datetime.now()
        db_sess = db_session.create_session()
        db_sess.add(user)
        db_sess.commit()
        return "Форма отправлена"


if __name__ == '__main__':
    main()
