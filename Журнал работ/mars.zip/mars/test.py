import argparse

parser = argparse.ArgumentParser()
parser.add_argument("arg", default=['no args'])
par = parser.parse_args()

db_session.global_init(par.arg)
db_sess = db_session.create_session()
for user in db_sess.query(User).all():
    if user.age < 18:
        print(user)
