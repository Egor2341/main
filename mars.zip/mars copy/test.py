import argparse
from mars.data import db_session
from mars.data.users import User
parser = argparse.ArgumentParser()
parser.add_argument("arg", default=['no args'])
par = parser.parse_args()

db_session.global_init(par.arg)
db_sess = db_session.create_session()
for user in db_sess.query(User).all():
    print(repr(user.id, user.surname, user.name))

